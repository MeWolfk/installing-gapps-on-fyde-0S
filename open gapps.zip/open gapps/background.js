chrome.app.runtime.onLaunched.addListener(function () {
  chrome.app.window.create('index.html', {
    bounds: {
      width: 600,
      height: 459,
    },
    minWidth: 600,
    minHeight: 459,
    frame: {
      type: 'chrome',
      color: '#ffffff',
    }
  });
});
